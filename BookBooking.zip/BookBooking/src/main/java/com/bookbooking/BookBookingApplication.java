package com.bookbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookBookingApplication.class, args);
	}
}
