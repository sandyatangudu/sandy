package com.airlines.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.airlines.beans.AirlineEntity;
import com.airlines.beans.FlightEntity;
import com.airlines.beans.UserEntity;
import com.airlines.dao.AirlinesDao;
import com.airlines.dao.FlightDao;
import com.airlines.dao.UserDao;


@RestController
@RequestMapping("/airline")
public class AirlineController {
	@Autowired
	AirlinesDao airlinesDao;
	//@Autowired
	//FlightDao flightDao;
	//@Autowired
	//UserDao userDao;
	
	@RequestMapping(value="/createairline" ,method = RequestMethod.POST)
	public AirlineEntity create(@RequestBody AirlineEntity airlineEntity){
		airlineEntity = (AirlineEntity) airlinesDao.save(airlineEntity);
	    return airlineEntity;
		
		}
	
		  
	/**   @RequestMapping(value="/creatflight" ,method = RequestMethod.POST)
		public FlightEntity create(@RequestBody FlightEntity flightEntity){
	    	flightEntity = (FlightEntity) flightDao.save(flightEntity);
		    return flightEntity;
			
		}
	**/
	/**@RequestMapping(value="/showairlines/{airlineCode}" ,method = RequestMethod.GET)
	public AirlineEntity read(@PathVariable int airlineCode) {
		AirlineEntity booking = (AirlineEntity) airlinesDao.findOne( airlineCode);
	    return booking;
	    }**/
	
	@RequestMapping(value="/showairlines" ,method = RequestMethod.GET)
	public List<AirlineEntity >read() {
		List<AirlineEntity> airlines=  airlinesDao.findAll();
	    return airlines;
	    }
	
	/** @RequestMapping(value="/creatuser" ,method = RequestMethod.POST)
		public UserEntity create(@RequestBody UserEntity userEntity){
		 userEntity = (UserEntity) userDao.save(userEntity);
		    return userEntity;
	 }**/
	
	@RequestMapping(value="/delete/{airlineCode}",method = RequestMethod.DELETE)
	public String  delete(@PathVariable int airlineCode) {
		airlinesDao.delete(airlineCode);
	    return "airlines deleted";
	}
		//@PathVariable Long id, @RequestBody Customer customer
	//customer = customerDAO.update(id, customer);

	@RequestMapping(value="/update/{airlineCode}",method = RequestMethod.PUT)
	public String  update(@PathVariable int totalSeats,  AirlineEntity airlineEntity) {
		airlineEntity = (AirlineEntity) airlinesDao.save(airlineEntity);
		return "updated";
	}

}
