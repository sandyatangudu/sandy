/*package com.airlines.dao;

import com.airlines.beans.FlightEntity;

public abstract class DAOImple implements  AirlinesDao{
	public   FlightEntity fetchFlights(){
		return null;
		
	}
	

}
*/