package com.airlines.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.airlines.beans.AirlineEntity;
import com.airlines.beans.UserEntity;

@Transactional
@Repository
public interface UserDao extends CrudRepository<UserEntity,Integer > {

}
