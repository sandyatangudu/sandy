package com.airlines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlinesBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlinesBookingApplication.class, args);
	}
}
