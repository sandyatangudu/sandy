package com.airlines.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Airline_123")
public class AirlineEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int airlineCode;
	@Column
	private double price;
	@Column
	private String airlineName;
	@Column
	private int totalSeats;
	@Column
	private int seatsAvalilable;

	@OneToMany(cascade = CascadeType.ALL)//, mappedBy="airlineEntity", orphanRemoval=true )
	//@JoinColumn(name = "airlineCode",nullable=true)
	private List<FlightEntity> flightEntity=new ArrayList<FlightEntity>();

	
	
	public List<FlightEntity> getFlightEntity() {
		return flightEntity;
	}
	
	
	public void setFlightEntity(List<FlightEntity> flightEntity) {
		if(flightEntity==null){
			//flightEntity=new ArrayList<FlightEntity>();
		}
		this.flightEntity = flightEntity;
	}

	public int getAirlineCode() {
		return airlineCode;
	}

	public void setAirlineCode(int airlineCode) {
		this.airlineCode = airlineCode;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	public int getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}

	public int getSeatsAvalilable() {
		return seatsAvalilable;
	}

	public void setSeatsAvalilable(int seatsAvalilable) {
		this.seatsAvalilable = seatsAvalilable;
	}

}
