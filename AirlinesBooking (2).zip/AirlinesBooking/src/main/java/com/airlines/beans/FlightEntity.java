package com.airlines.beans;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name = "Flight_123")
public class FlightEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ID;
	@Column
	private String origin;
	@Column
	private String destination;
	@Column
	private String departureDate;


	 @OneToMany(cascade = CascadeType.ALL)
	private List<UserEntity> user;
	//@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	//@JoinColumn(name = "airlineCode",nullable=false)
	//private AirlineEntity airlineEntity;

	/*public AirlineEntity getAirlineEntity() {
		return airlineEntity;
	}

	public void setAirlineEntity(AirlineEntity airlineEntity) {
		this.airlineEntity = airlineEntity;
	}*/

	public int getID() {
		return ID;
	}

	public List<UserEntity> getUser() {
		return user;
	}

	public void setUser(List<UserEntity> user) {
		this.user = user;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

}
