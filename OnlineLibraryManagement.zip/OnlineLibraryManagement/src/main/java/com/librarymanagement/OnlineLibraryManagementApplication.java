package com.librarymanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineLibraryManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineLibraryManagementApplication.class, args);
	}
}
