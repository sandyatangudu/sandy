package com.librarymanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.librarymanagement.beans.Member;
import com.librarymanagement.dao.BookingDao;

@RestController
public class BookingController {
	@Autowired
	BookingDao bookingDao;

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public String addBooks(@RequestBody Member book) {
		System.out.println("22222222222");
		bookingDao.save(book);
		return "Status 200  Successfly created Books";
	}
	@RequestMapping(value="/showmembers" ,method = RequestMethod.GET)
	public List<Member>read() {
		List<Member> members= bookingDao.findAll();
	    return members;
	    }
	@RequestMapping(value="/delete/{memb_id}",method = RequestMethod.DELETE)
	public String  delete(@PathVariable int airlineCode) {
		bookingDao.delete(airlineCode);
	    return "airlines deleted";
	}
	/**@RequestMapping(value="/update/{memb_id}",method = RequestMethod.PUT)
	public String  update(@PathVariable int memb_id,  Member member) {
		member = (Member) bookingDao.save(member);
		return "updated";
	}**/
	@RequestMapping(value = "/add/{id}", method = RequestMethod.PUT)
	public Member addBook(@PathVariable int id, @RequestBody Member member) {
		Member book1 = bookingDao.findOne(id);
		book1.setName(member.getName());
		bookingDao.save(book1);
		return book1;
	} 
	
}
