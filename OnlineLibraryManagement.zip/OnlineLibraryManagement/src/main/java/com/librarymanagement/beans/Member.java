package com.librarymanagement.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Member_1")
public class Member {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int memb_id;
	@Column
	private String memb_date;
	@Column
	private String memb_type;
	@Column
	private String address;
	@Column
	private String name;
	@Column
	private String exp_date;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Booking> booking=new ArrayList<Booking>();
	


	public List<Booking> getBooking() {
		return booking;
	}

	public void setBooking(List<Booking> booking) {
		this.booking = booking;
	}
	/**@OneToMany(cascade = CascadeType.ALL)
	private List<Books> books;
	
	public List<Books> getBooks() {
		return books;
	}
	public void setBooks(List<Books> books) {
		this.books = books;
	}**/
	public int getMemb_id() {
		return memb_id;
	}
	public Member() {
		super();
	}
	
	public void setMemb_id(int memb_id) {
		this.memb_id = memb_id;
	}
	public String getMemb_date() {
		return memb_date;
	}
	public void setMemb_date(String memb_date) {
		this.memb_date = memb_date;
	}
	public String getMemb_type() {
		return memb_type;
	}
	public void setMemb_type(String memb_type) {
		this.memb_type = memb_type;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExp_date() {
		return exp_date;
	}
	public void setExp_date(String exp_date) {
		this.exp_date = exp_date;
	}
	
	
	
}
